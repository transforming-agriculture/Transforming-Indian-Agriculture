This is the project for using Deep Learning and Machine Learning in Indian Agriculture. 

This is a humble effort for putting this technology in Indian Agriculture and making the situaion better for the Indian Agriculture.


